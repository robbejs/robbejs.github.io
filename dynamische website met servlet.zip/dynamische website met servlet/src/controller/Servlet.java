package controller;

import db.BikeRepository;
import domain.Bike;
import domain.Category;
import domain.DomainException;
import org.junit.runner.Request;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet("/Servlet")
public class Servlet extends HttpServlet {

    private String destination;
    private RequestDispatcher view;

    private BikeRepository bikeDB = new BikeRepository();
    private HttpSession session;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String command =request.getParameter("command");

        if (command == null || command.isEmpty()){
            command = "home";
        }

        switch (command){
            case "home":
                destination = home(request, response);
                break;
            case "overview":
                destination = overview(request, response);
                break;
            case "details":
                destination = details(request,response);
                break;
            case "addBike":
            destination = addbike(request, response);
            break;
            case "nieuwsbrief":
                destination = nieuwsbrief(request, response);
                break;
            case "keuzeNieuwsbrief":
                destination = keuzeNieuwsbrief(request, response);
                break;
            case "submitBike":
                destination = submitBike(request, response);
                break;
            default:
                destination = home(request,response);
        }

        view = request.getRequestDispatcher(destination);
        view.forward(request,response);
    }

    private String submitBike(HttpServletRequest request, HttpServletResponse response) {
        ArrayList<String> errors = new ArrayList<>();

        Bike bike = new Bike();
        setItemId(request, errors, bike);
        setBrand(request, errors, bike);
        setCategory(request, errors, bike);
        setDescription(request,errors,bike);
        setPrice(request, errors, bike);

        if (errors.size() == 0){
            try{
                bikeDB.add(bike);
                return overview(request,response);
            }catch (IllegalArgumentException e){
                errors.add(e.getMessage());
                request.setAttribute("errors", errors);
                return "bike.jsp";
            }
        }else{
            return "bike.jsp";
        }
    }

    private void setDescription(HttpServletRequest request, ArrayList<String> errors, Bike bike) {
        String description = request.getParameter("description");
        try {
            bike.setDescription(description);
            request.setAttribute("previousDescription", description);
        } catch (DomainException e) {
            errors.add(e.getMessage());
        }
    }

    private void setPrice(HttpServletRequest request, ArrayList<String> errors, Bike bike) {
        String price = request.getParameter("price");

        try {
            bike.setPrice(Double.parseDouble(price));
            request.setAttribute("previousPrice", price);
        }catch (NumberFormatException e){
            errors.add(e.getMessage());
        }catch (DomainException e){
            errors.add(e.getMessage());
        }
    }

    private void setCategory(HttpServletRequest request, ArrayList<String> errors, Bike bike) {
        String category = request.getParameter("category");

        try{
            bike.setCategory(Category.valueOf(category));
            request.setAttribute("previousCategory", category);
        }catch (DomainException e){
            errors.add(e.getMessage());
        }
    }

    private void setBrand(HttpServletRequest request, ArrayList<String> errors, Bike bike) {
        String brand = request.getParameter("brand");

        try {
            bike.setBrand(brand);
            request.setAttribute("previous_input_brand", brand);
        } catch (DomainException e) {
            errors.add(e.getMessage());
        }
    }

    private void setItemId(HttpServletRequest request, ArrayList<String> errors, Bike bike) {
        String itemId = request.getParameter("itemId");

        try {
            bike.setItemId(itemId);
            request.setAttribute("previousItemId",itemId);
        }catch (DomainException e){
            errors.add(e.getMessage());
        }
    }

    private String keuzeNieuwsbrief(HttpServletRequest request, HttpServletResponse response) {

        String choice = request.getParameter("nieuwsbrief");
        if (choice == null) {
            response.addCookie(new Cookie("visibleNB", "false"));
            request.setAttribute("visibleNB", false);
        } else if (choice.equals("nieuwsbrief")) {
            response.addCookie(new Cookie("visibleNB", "true"));
            request.setAttribute("visibleNB", true);
        }

        return "index.jsp";
    }

    private void applyCookieNieuwsBrief(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        request.setAttribute("visibleNB", false);

        if (cookies != null || cookies.length != 0) {
            for (int i = 0; i < cookies.length; i++) {
                if (cookies[i].getName().equals("visibleNB")) {
                    if (cookies[i].getValue().equals("true"))
                        request.setAttribute("visibleNB", true);
                    break;
                }
            }
        }
    }

    private String nieuwsbrief(HttpServletRequest request, HttpServletResponse response) {
        return "home.jsp";
    }

    private String addbike(HttpServletRequest request, HttpServletResponse response) {
        applyCookieNieuwsBrief(request);
        return  "bikeAdd.jsp";
    }


    private String details(HttpServletRequest request, HttpServletResponse response) {

        applyCookieNieuwsBrief(request);

        Bike bike = bikeDB.get(request.getParameter("itemId"));

        if (bike != null){
            request.setAttribute("bike", bike);
        }

        return "bikeDetail.jsp";
    }

    private String overview(HttpServletRequest request, HttpServletResponse response) {

        applyCookieNieuwsBrief(request);
        request.setAttribute("bikeList", bikeDB.getAll());
        return "bikeOverview.jsp";
    }

    private String home(HttpServletRequest request, HttpServletResponse response) {

        applyCookieNieuwsBrief(request);

        return "index.jsp";
    }
}
