package domain;

public enum Category {
	ROAD, CITY;
}
