﻿using Cells;
using DataStructures;
using PiCross;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using Utility;
using ViewModel;
using Grid = DataStructures.Grid;
using Size = DataStructures.Size;

namespace View
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>    
    /// 

    public class SquareConverter : IValueConverter
    {
        public Object Filled { get; set; }
        public Object Empty { get; set; }
        public Object Unkown { get; set; }
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {

            var square = (Square)value;
            if (square == Square.EMPTY)
            {
                return Empty;
            }
            else if (square == Square.FILLED)
            {
                return Filled;
            }
            else
            {
                return Unkown;
            }
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = new Navigator();
        }
    }

    public class Navigator : INotifyPropertyChanged
    {
        public MyViewModel myViewModel { get; set; }

        private Screen currentScreen;

        public Navigator()
        {
            this.myViewModel = new MyViewModel();
            this.currentScreen = new StartScherm(this);
        }

        public Screen CurrentScreen
        {
            get
            {
                return currentScreen;
            }
            set
            {
                this.currentScreen = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CurrentScreen)));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }

    public abstract class Screen
    {
        protected readonly Navigator navigator;

        public MyViewModel MyViewModel { get; set; }

        protected Screen(Navigator navigator)
        {
            this.navigator = navigator;
            this.MyViewModel = navigator.myViewModel;
            
        }

        protected void Goto(Screen screen)
        {
            this.navigator.CurrentScreen = screen;
        }

        protected void selecteerRij(Screen screen)
        {
            MyViewModel.loadPuzzles();
            Goto(screen);
        }

        protected void stop()
        {
            MyViewModel.onStop();
            var uri = new Uri(@"../../../../better jungle wins.mp3", UriKind.RelativeOrAbsolute);
            var player = new MediaPlayer();
            player.Open(uri);
            player.Play();
        }
    }


    public class Game : Screen
    {
        public Game(Navigator navigator) : base(navigator)
        {
            GoStartScherm = new NavigateCommand(() => Goto(new StartScherm(navigator)));
            MyViewModel.SetPuzzle();
            this.MyViewModel.Playablepuzzle.IsSolved.ValueChanged += () => { if (MyViewModel.Playablepuzzle.IsSolved.Value) { stop(); } };
        }
        public ICommand GoStartScherm { get; }

    }

    public class StartScherm : Screen
    {
        public StartScherm(Navigator navigator) : base(navigator)
        {
            GoGame = new NavigateCommand(() => Goto(new Game(navigator)));
            GoSelect= new NavigateCommand(() => Goto(new Select(navigator)));
        }

        public ICommand GoGame { get; }

        public ICommand GoSelect { get; }
    }

    public class Select : Screen
    {
        public Select(Navigator navigator) : base(navigator)
        {
            GoStartScherm = new NavigateCommand(() => Goto(new StartScherm(navigator)));
            GoGame = new NavigateCommand(() => Goto(new Game(navigator)));
            SelectConfirm = GoGame;
            VeranderRij = new NavigateCommand(() => selecteerRij(new Select(navigator)));
        }

        public ICommand VeranderRij { get; }

        public ICommand GoStartScherm { get; }

        public ICommand GoGame { get; }

        public ICommand SelectConfirm { get; }


    }

    public class SolvedConverter : IValueConverter

    {
        public object solved { get; set; }
        public object unsolved { get; set; }

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var opgelost = (bool)value;


            if (opgelost == true)
            {
                return solved;
            }
            else
            {
                return unsolved;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        } 
    }
}
