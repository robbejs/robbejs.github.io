﻿using Cells;
using PiCross;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace ViewModel
{
    public class klikCommand : ICommand
    {
        private readonly Action action;

        private readonly IVar<Square> contents;
        private readonly string v;

        public klikCommand(IVar<Square> contents,string v)
        {
            this.contents = contents;
            this.v = v;
        }

        public event EventHandler CanExecuteChanged { add { } remove { } }

        public bool CanExecute(object parameter)
        {
            return (v.Equals("links") || v.Equals("rechts"));
        }

        public void Execute(object parameter)
        {
            {
                if (v.Equals("links"))
                {
                    if (this.contents.Value == Square.FILLED)
                    {
                        this.contents.Value = Square.UNKNOWN;
                    }
                    else
                    {
                        this.contents.Value = Square.FILLED;
                        Console.WriteLine(this.contents.Value);
                    }
                }

                if (v.Equals("rechts"))
                {
                    if (this.contents.Value == Square.EMPTY)
                    {
                        this.contents.Value = Square.UNKNOWN;
                    }
                    else
                    {
                        this.contents.Value = Square.EMPTY;
                        Console.WriteLine(this.contents.Value);
                    }
                }
            }
        }
    }
}

