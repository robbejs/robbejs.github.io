﻿using DataStructures;
using PiCross;

namespace ViewModel
{
    internal class PlayableSquare
    {
        private MyViewModel myViewModel;
        private IPlayablePuzzleSquare var;
        private Vector2D position;

        public PlayableSquare(MyViewModel myViewModel, IPlayablePuzzleSquare var, Vector2D position)
        {
            this.myViewModel = myViewModel;
            this.var = var;
            this.position = position;
        }
    }
}