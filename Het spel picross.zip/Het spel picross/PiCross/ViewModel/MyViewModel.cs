﻿using PiCross;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Threading;
using System.Windows.Media;
using Utility;
using System.Windows;
using DataStructures;
using Cells;

namespace ViewModel
{
    public class MyViewModel
    {
        private DispatcherTimer timer;
        private PiCrossFacade facade;
        public String gridRijen { get; set; }
        private List<IPuzzleLibraryEntry> gamedata;

        public IPlayablePuzzle Playablepuzzle { get; set; }
        public IPuzzleLibraryEntry activePuzzle { get; set; }
        public List<IPuzzleLibraryEntry> puzzels
        {
            get
            {
                return gamedata;
            }
            set
            {
                this.gamedata = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(puzzels)));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public MyViewModel()
        {
            facade = new PiCrossFacade();
            loadPuzzles();
        }

        public void loadPuzzles()
        {
            var intRij = 1;
            this.gamedata = facade.LoadGameData("../../../../python/picross.zip").PuzzleLibrary.Entries.ToList();

            if (gridRijen == null || gridRijen == String.Empty)
            {
                this.puzzels = this.gamedata;
            }
            else
            {
                this.puzzels.Clear();
                intRij = int.Parse(gridRijen);
                foreach (IPuzzleLibraryEntry p in facade.LoadGameData("../../../../python/picross.zip").PuzzleLibrary.Entries.ToList())
                {
                    if(p.Puzzle.RowConstraints.Count() == intRij)
                    {
                       this.puzzels.Add(p);
                    }
                }
            }
        }

        public void SetPuzzle()
        {
            if(activePuzzle == null)
            {               
                var puzzle = Puzzle.FromRowStrings(
                        "xxxxx",
                        "x...x",
                        "x.x.x",
                        "x...x",
                        "xxxxx"
                        );
                this.Playablepuzzle = facade.CreatePlayablePuzzle(puzzle);
            }
            else
            {
                this.Playablepuzzle = facade.CreatePlayablePuzzle(activePuzzle.Puzzle);
            }
            this.Grid = Playablepuzzle.Grid;
            this.Grid = Grid.Map((position, var) => new PlayableSquare(this, var.Contents, var.Position)).Copy();
            this.Chronometer = new Chronometer();

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(250);
            timer.Tick += (o, s) => Chronometer.Tick();
            timer.Start();
            OnStart();
        }

        public Chronometer Chronometer { get; set; }

        public IGrid<IPlayablePuzzleSquare> Grid { get; private set; }

        private void OnStart()
        {
            Chronometer.Start();
        }

        public void onStop()
        {
            Chronometer.Pause();
        }

        public class PlayableSquare : IPlayablePuzzleSquare
        {
            public ICommand linkerKlik { get; set; }
            public ICommand rechterKlik { get; set; }

            public Cell<Square> Contents { get; }

            public Vector2D Position { get; }

            public PlayableSquare(MyViewModel parent, Cell<Square> square, Vector2D position)
            {
                this.Contents = square;
                this.Position = position;
                linkerKlik = new klikCommand(Contents, "links");
                rechterKlik = new klikCommand(Contents, "rechts");
            }
        }
    }
}
