package team_15.team_15.service;

public class ServiceException extends Throwable {

    public ServiceException(String message){
        super(message);
    }
}
