package team_15.team_15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Team15ApplicationTests {

    @Test
    void contextLoads() {
    }

}
