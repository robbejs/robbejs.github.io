package SO.toDoList;

public enum Role {
    ADMIN, CLIENT
}
