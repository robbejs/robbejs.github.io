package SO.toDoList.Controller;
import SO.toDoList.model.dto.TagDTO;
import SO.toDoList.model.service.TagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import javax.validation.Valid;

@Controller
public class TagController {
    private TagService service;

    @Autowired
    public TagController(TagService service) {
        this.service = service;
    }

    @RequestMapping("/tags")
    public String getTags(Model model){
        model.addAttribute("tag", service.getTags());
        return "tagOverview";
    }

    @RequestMapping("/tags/newTag")
    public String goToAddTag(){
        return "addTag";
    }

    @PostMapping("/tags/addNewTag")
    public String addTag(@ModelAttribute @Valid TagDTO tagDTO, BindingResult bindingResult){
        if (bindingResult.hasErrors()) {
            return "addTag";
        }
        service.addTag(tagDTO);
        return "addTag";
    }

}
