package SO.toDoList.model.service;

import SO.toDoList.model.dto.TagDTO;
import SO.toDoList.model.dto.TaskDTO;
import SO.toDoList.model.entity.Tag;

import java.util.List;

public interface TagService {
    void addTag(TagDTO tagDTO);
    void deleteTag(int id);
    List<Tag> getTags();
}
