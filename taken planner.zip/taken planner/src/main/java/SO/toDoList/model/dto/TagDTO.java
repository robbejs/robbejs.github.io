package SO.toDoList.model.dto;
import org.hibernate.validator.constraints.UniqueElements;
import javax.validation.constraints.NotNull;

public class TagDTO {
    @NotNull
    @UniqueElements
    private String naam;

    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }
}
