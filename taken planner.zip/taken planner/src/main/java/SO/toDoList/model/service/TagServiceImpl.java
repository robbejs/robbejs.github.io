package SO.toDoList.model.service;
import SO.toDoList.model.dto.TagDTO;
import SO.toDoList.model.entity.Tag;
import SO.toDoList.model.repository.TagRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class TagServiceImpl implements TagService {
    private final TagRepository repository;

    @Autowired
    public TagServiceImpl(TagRepository repository) {
        this.repository = repository;
    }

    @Override
    public void addTag(TagDTO tagDTO) {

    }

    @Override
    public void deleteTag(int id) {

    }

    @Override
    public List<Tag> getTags() {
        return null;
    }
}
