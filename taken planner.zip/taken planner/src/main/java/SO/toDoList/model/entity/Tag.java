package SO.toDoList.model.entity;
import org.hibernate.validator.constraints.UniqueElements;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Entity
public class Tag {
    @Id
    @GeneratedValue
    private long id;

    @NotNull
    @UniqueElements
    private String naam;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }
}
