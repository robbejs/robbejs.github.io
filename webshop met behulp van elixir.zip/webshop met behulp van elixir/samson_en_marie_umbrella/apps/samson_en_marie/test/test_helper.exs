ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(SamsonEnMarie.Repo, :manual)
