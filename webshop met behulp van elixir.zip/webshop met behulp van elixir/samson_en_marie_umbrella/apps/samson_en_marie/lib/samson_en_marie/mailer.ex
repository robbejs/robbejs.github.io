defmodule SamsonEnMarie.Mailer do
  use Bamboo.Mailer, otp_app: :samson_en_marie
end
