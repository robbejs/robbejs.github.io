defmodule Translations.Gettext do
  @moduledoc """
  ...
  """
  use Gettext, otp_app: :translations
end
