defmodule SamsonEnMarieWeb.UserView do
  use SamsonEnMarieWeb, :view
end
