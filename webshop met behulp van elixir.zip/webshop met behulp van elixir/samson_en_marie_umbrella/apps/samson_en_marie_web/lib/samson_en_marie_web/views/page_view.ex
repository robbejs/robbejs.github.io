defmodule SamsonEnMarieWeb.PageView do
  use SamsonEnMarieWeb, :view
end
