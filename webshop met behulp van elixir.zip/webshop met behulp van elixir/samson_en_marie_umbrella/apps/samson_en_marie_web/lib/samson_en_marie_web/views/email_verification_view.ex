defmodule SamsonEnMarieWeb.EmailVerificationView do
  use SamsonEnMarieWeb, :view
end
