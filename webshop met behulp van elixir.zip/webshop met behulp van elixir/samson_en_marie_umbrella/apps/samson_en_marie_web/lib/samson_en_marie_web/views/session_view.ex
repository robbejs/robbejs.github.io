defmodule SamsonEnMarieWeb.SessionView do
  use SamsonEnMarieWeb, :view
end
