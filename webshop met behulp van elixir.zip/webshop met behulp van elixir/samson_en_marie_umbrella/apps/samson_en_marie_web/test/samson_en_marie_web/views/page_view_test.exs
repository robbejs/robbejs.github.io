defmodule SamsonEnMarieWeb.PageViewTest do
  use SamsonEnMarieWeb.ConnCase, async: true
end
