```SQL
GRANT ALL PRIVILEGES ON SCHEMA stormy_whales_3 TO r0596126, r0803569, r0790963, r0786792, r0756798 WITH GRANT OPTION;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA stormy_whales_3 TO r0596126, r0803569, r0790963, r0786792, r0756798 WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON SCHEMA stormy_whales_3 TO local_r0596126, local_r0803569, local_r0790963, local_r0786792, local_r0756798, hakkaton_03;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA stormy_whales_3 TO local_r0596126, local_r0803569, local_r0790963, local_r0786792, local_r0756798, hakkaton_03;
```

```sql
SET search_path TO stormy_whales_3;
CREATE TABLE courses
(
	id bigserial,
    name varchar(255) NOT NULL,
	opo_code varchar(50) NOT NULL,
	register_code CHAR(16),
	user_id bigint,
	PRIMARY KEY (id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);
GRANT ALL ON courses TO local_r0596126, local_r0803569, local_r0790963, local_r0786792, local_r0756798, local_r0762952, local_r0662195, local_r0758752, hakkaton_03;
GRANT ALL ON courses TO r0596126, r0803569, r0790963, r0786792, r0756798, r0762952, r0662195, r0758752;
```

## Courses_Users table
```sql
SET search_path TO stormy_whales_3;
CREATE TABLE courses_users
(
	course_id bigserial,
	user_id bigint,
    "group" varchar(20),
	PRIMARY KEY (user_id, course_id),
    FOREIGN KEY (course_id) REFERENCES courses(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);
GRANT ALL ON courses_users TO local_r0596126, local_r0803569, local_r0790963, local_r0786792, local_r0756798, local_r0762952, local_r0662195, local_r0758752, hakkaton_03;
GRANT ALL ON courses_users TO r0596126, r0803569, r0790963, r0786792, r0756798, r0762952, r0662195, r0758752;
```

## Codes table
```sql
SET search_path TO stormy_whales_3;
CREATE TABLE codes
(
	lesson_id bigserial
	code varchar(16) NOT NULL,
    timestamp timestamp NOT NULL,
	PRIMARY KEY (code),
    FOREIGN KEY (lesson_id) REFERENCES lessons(id)
);
CREATE UNIQUE INDEX code_index ON codes(code);
GRANT ALL ON codes TO local_r0596126, local_r0803569, local_r0790963, local_r0786792, local_r0756798, local_r0762952, local_r0662195, local_r0758752, hakkaton_03;
GRANT ALL ON codes TO r0596126, r0803569, r0790963, r0786792, r0756798, r0762952, r0662195, r0758752;
```
## Users lessons
````sql
SET search_path TO stormy_whales_3;
CREATE TABLE users_lessons
(
	lesson_id bigserial,
	user_id bigint,
    confirmed boolean default 'no',
	PRIMARY KEY (lesson_id, user_id),
    FOREIGN KEY (lesson_id) REFERENCES lessons(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

GRANT ALL ON users_lessons TO local_r0596126, local_r0803569, local_r0790963, local_r0786792, local_r0756798, local_r0762952, local_r0662195, local_r0758752, hakkaton_03;
GRANT ALL ON users_lessons TO r0596126, r0803569, r0790963, r0786792, r0756798, r0762952, r0662195, r0758752;
````

## Lessons table
```sql
CREATE TABLE lessons 
(
    id bigserial,
    description text,
    timestamp timestamp NOT NULL,
    is_online boolean default 'no',
    "group" varchar(20),
    duration double precision,
    course_id bigint,
    
    PRIMARY KEY (id),
    FOREIGN KEY (course_id) REFERENCES courses(id)
);
GRANT ALL ON lessons TO local_r0596126, local_r0803569, local_r0790963, local_r0786792, local_r0756798, local_r0762952, local_r0662195, local_r0758752, hakkaton_03;
GRANT ALL ON lessons TO r0596126, r0803569, r0790963, r0786792, r0756798, r0762952, r0662195, r0758752;
```
