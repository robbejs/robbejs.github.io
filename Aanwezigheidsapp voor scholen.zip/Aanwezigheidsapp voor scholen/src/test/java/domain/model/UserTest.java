package domain.model;

import org.junit.Test;
import ucll.project.domain.model.RoleEnum;
import ucll.project.domain.model.User;

import static org.junit.Assert.*;

public class UserTest {
    @Test
    public void createNewUser() {
        User user = new User("123", "FirstName", "LastName", "WACHTWOORD", RoleEnum.STUDENTADMINISTRATION);

        assertEquals(0, user.getId());
        assertEquals("123", user.getUserId());
        assertEquals("FirstName", user.getFirstName());
        assertEquals("LastName", user.getLastName());
        assertEquals("WACHTWOORD", user.getPassword());
    }

    @Test
    public void createNewUserOther(){
        User user= new User(5, "123", "FirstName", "LastName", "WACHTWOORD", RoleEnum.STUDENTADMINISTRATION);

        assertEquals(5, user.getId());
        assertEquals("123", user.getUserId());
        assertEquals("FirstName", user.getFirstName());
        assertEquals("LastName", user.getLastName());
        assertEquals("WACHTWOORD", user.getPassword());
    }
}
