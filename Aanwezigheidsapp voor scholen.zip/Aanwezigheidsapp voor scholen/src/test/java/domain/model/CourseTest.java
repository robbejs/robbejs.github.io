package domain.model;

import org.junit.Test;
import ucll.project.domain.model.Course;
import ucll.project.domain.model.DomainException;

import static org.junit.Assert.assertEquals;

public class CourseTest {
    @Test
    public void createCourseShoulldSetCorrectAttributes() {
        Course course = new Course(999, "Naaam", "OPO Code", "Register Code");

        assertEquals(999, course.getId());
        assertEquals("Naaam", course.getName());
        assertEquals("OPO Code", course.getOpoCode());
        assertEquals("Register Code", course.getRegisterCode());
    }

    @Test(expected = DomainException.class)
    public void createCourseWithIdZeroShouldReturnError() {
        Course course = new Course(0, "Naaaaam", "OPOCode", "RegisterCode");
    }

    @Test(expected = DomainException.class)
    public void createCourseWithNegativeIdShouldReturnError() {
        Course course = new Course(-500, "Naaaaam", "OPOCode", "RegisterCode");
    }

    @Test(expected = DomainException.class)
    public void createCourseWithEmptyNameShouldReturnError() {
        Course course = new Course(999, " ", "OPO Code", "Register Code");
    }

    @Test(expected = DomainException.class)
    public void createCourseWithEmptyOpoCodeShouldReturnError() {
        Course course = new Course(999, "A course", null, "Register Code");
    }
}
