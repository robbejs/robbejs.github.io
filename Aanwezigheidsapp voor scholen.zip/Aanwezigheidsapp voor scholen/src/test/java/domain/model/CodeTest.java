package domain.model;

import org.junit.Test;
import ucll.project.domain.model.Code;
import java.time.LocalDateTime;

import static org.junit.Assert.*;

public class CodeTest {
    @Test
    public void newCodeShouldBeCreated() {
        Code code = new Code(5, LocalDateTime.now());

        assertEquals(5, code.getCourseId());
        assertNotNull(code.getCode());
    }

    @Test
    public void existingCodeShouldBeCorrect() {
        Code code = new Code(10, "hallo123", LocalDateTime.now());

        assertEquals(10, code.getCourseId());
        assertEquals("hallo123", code.getCode());
    }
}
