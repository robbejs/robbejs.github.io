package ucll.project.ui;

public class Config {
    public static String BASE_URL = "https://dev-presence-stormy-whales-3.project2.projectweek.be/Controller";



}
