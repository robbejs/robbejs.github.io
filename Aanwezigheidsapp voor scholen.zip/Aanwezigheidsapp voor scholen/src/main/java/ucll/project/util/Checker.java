package ucll.project.util;

import ucll.project.domain.model.NotAuthorizedException;
import ucll.project.domain.model.RoleEnum;
import ucll.project.domain.model.User;

import javax.servlet.http.HttpServletRequest;

public class Checker {

    public static boolean isEmptyString(String s) {
        return s == null || s.trim().isEmpty();
    }

    public static void checkRole(HttpServletRequest request, RoleEnum[] roles) {
        User user = getUserInSession(request);
        if (user == null) throw new NotAuthorizedException("You are not authorized to see this content!");

        boolean allowed = false;
        for (RoleEnum role: roles) {
            if (user.getRoleEnum().equals(role)) {
                allowed = true;
                break;
            }
        }

        if (!allowed) throw new NotAuthorizedException("You are not authorized to see this content!");
    }

    public static User getUserInSession(HttpServletRequest request) {
        return (User) request.getSession().getAttribute("user");
    }

    public static void isUserloggedIn(HttpServletRequest request) {
        if (request.getSession().getAttribute("user") == null) throw new NotAuthorizedException("You are not authorized to see this content!");
    }
}
