package ucll.project.util;

import java.util.Properties;

public class Secret {
     public static void setPass(Properties properties) {
         properties.setProperty("user", "hakkaton_03");
         properties.setProperty("password", "cut8Ie0aio5tfkow");
     }
}
