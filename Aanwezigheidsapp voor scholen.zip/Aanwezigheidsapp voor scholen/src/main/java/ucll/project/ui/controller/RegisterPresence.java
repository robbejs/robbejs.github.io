package ucll.project.ui.controller;

import ucll.project.domain.model.Code;
import ucll.project.domain.model.Lesson;
import ucll.project.domain.model.RoleEnum;
import ucll.project.domain.model.User;
import ucll.project.domain.service.DatabaseService;
import ucll.project.util.Checker;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

public class RegisterPresence extends RequestHandler {
    Lesson lesson;

    public RegisterPresence(String command, DatabaseService service) {
        super(command, service);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (request.getParameter("id") == null || request.getParameter("id").trim().equals("")) {
            response.sendRedirect(request.getContextPath() + "/Controller");
            return "index.jsp";
        }

        int id = Integer.parseInt(request.getParameter("id"));
        this.lesson = getService().getLessonService().getById(id);

        request.setAttribute("test", id);
        request.setAttribute("lesson", getService().getLessonService().getById(id));
        request.setAttribute("tijdstip", lesson.getLessonTime(lesson.getTimestamp(), lesson.getDuration()));

        if (request.getMethod().equals("POST"))
            return handlePOST(request, response);

        return "registerPresence/register.jsp";
    }


    public String handlePOST(HttpServletRequest request, HttpServletResponse response) throws IOException {
        RoleEnum[] roles = {RoleEnum.STUDENT};
        Checker.checkRole(request, roles);

        ArrayList<String> errors = new ArrayList<>();
        String codeString = request.getParameter("code");
        User user = (User) request.getSession().getAttribute("user");

        String id = request.getParameter("id");
        String command = request.getParameter("command");

        if (codeString == null || codeString.trim().equals("")) {
            errors.add("Het code veld is verplicht.");
            return returnWithErrors(request, errors);
        }

        Code code = getService().getCodeService().getByCodeByLesson(codeString, this.lesson.getId());

        if (code != null && !code.hasExpired()) {
            getService().getLessonService().registerUser(user.getId(), this.lesson.getId());
            response.sendRedirect(request.getContextPath() + "/Controller?success=1");
            return "";
        }

        errors.add("De code die je ingaf is verlopen of ongeldig.");
        return returnWithErrors(request, errors);
    }

    private String returnWithErrors(HttpServletRequest request, ArrayList<String> errors) {
        request.setAttribute("errors", errors);

        return "registerPresence/register.jsp";
    }
}