package ucll.project.ui.controller;

import ucll.project.domain.model.User;
import ucll.project.domain.service.DatabaseService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class Login extends RequestHandler {
    public Login(String command, DatabaseService service) {
        super(command, service);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (request.getMethod().equalsIgnoreCase("GET")) return "auth/login.jsp";

        String userId = request.getParameter("userId");
        String password = request.getParameter("password");
        User user = getService().getUser(userId);

        if (user != null && user.verifyPasswordWithHash(password)) {
            request.getSession().setAttribute("user", user);
            String url;

            switch (user.getRoleEnum()) {
                case STUDENT:
                    url = "Controller";
                    break;
                case LECTOR:
                    url = "Controller?command=Courses";
                    break;
                case STUDENTADMINISTRATION:
                case TRAJECTORYCOACH:
                    url = "Controller?command=StudentOverview";
                    break;
                default:
                    url = "Controller?command=Index";
            }

            response.sendRedirect(request.getContextPath() + "/" + url);
        }

        request.setAttribute("error", "De inloggegevens kloppen niet");

        return "auth/login.jsp";
    }
}
