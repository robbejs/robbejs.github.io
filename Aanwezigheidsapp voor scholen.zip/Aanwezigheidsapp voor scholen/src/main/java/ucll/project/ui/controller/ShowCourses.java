package ucll.project.ui.controller;

import org.openqa.selenium.json.JsonOutput;
import ucll.project.domain.model.Code;
import ucll.project.domain.model.Course;
import ucll.project.domain.model.Lesson;
import ucll.project.domain.model.RoleEnum;
import ucll.project.domain.model.User;
import ucll.project.domain.service.DatabaseService;
import ucll.project.util.Checker;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

public class ShowCourses extends RequestHandler {
    public ShowCourses(String command, DatabaseService service) {
        super(command, service);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) {
        if (request.getMethod().equals("GET"))
            return handleGET(request, response);

        return "errors/405.jsp";
    }

    /**
     *
     * @param request
     * @param response
     * @return show jsp
     */
    public String handleGET(HttpServletRequest request, HttpServletResponse response) {
        int lesson_id = Integer.parseInt(request.getParameter("id"));
        RoleEnum[] roles = {RoleEnum.LECTOR};
        Checker.checkRole(request, roles);

        Lesson lesson = getService().getLessonService().getById(lesson_id);

        if (lesson == null) return "errors/404.jsp";

        List<User> users = getService().getUserService().getUserPerLesson(lesson_id);
        List<Code> codes = getService().getCodeService().getAllCodesById(lesson_id);

        request.setAttribute("users", users);
        request.setAttribute("codes", codes);
        request.setAttribute("lesson", lesson);

        return "courses/lesson.jsp";
    }
}
