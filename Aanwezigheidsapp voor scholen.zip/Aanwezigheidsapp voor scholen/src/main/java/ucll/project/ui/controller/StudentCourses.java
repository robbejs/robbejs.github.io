package ucll.project.ui.controller;

import ucll.project.domain.model.Lesson;
import ucll.project.domain.model.User;
import ucll.project.domain.service.DatabaseService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class StudentCourses extends RequestHandler {

    public StudentCourses(String command, DatabaseService service) {
        super(command, service);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        User user = (User) request.getSession().getAttribute("user");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/Controller");
            return "";
        }

        int id = getService().getUserService().getIdUser(user.getUserId());
        request.setAttribute("lessons", getService().getLessonService().getStudentLessons(id));

        return "registerPresence/RegisterOverview.jsp";
    }
}
