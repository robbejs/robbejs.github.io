package ucll.project.ui.controller;

import ucll.project.domain.model.DomainException;
import ucll.project.domain.model.NotAuthorizedException;
import ucll.project.domain.service.DatabaseService;
import ucll.project.util.DbConnectionService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/Controller")
public class Controller extends HttpServlet {
    private HandlerFactory handlerFactory;
    private DatabaseService service;

    @Override
    public void init() throws ServletException {
        super.init();
        handlerFactory = new HandlerFactory();
        service = new DatabaseService();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // checks connection with database and reconnects when necessary
            // with singleton-pattern: application is connected to database when initiated (cfr util.AppContextListener)
            // when the connection with the database has been idle for some time, the database itself disconnects the application.
            // therefore the application must reconnect to the database
            try {
                if (DbConnectionService.getDbConnection().isClosed()) {
                    System.out.println("Connection has been closed");
                    DbConnectionService.reconnect();
                    this.service = new DatabaseService();
                }
            } catch (SQLException e) {
                throw new DomainException(e.getMessage(), e);
            }

            String command = request.getParameter("command");
            if (command == null || command.trim().isEmpty()) {
                command = "Index";
            }

            request.setAttribute("pageCommand", command.toLowerCase());

            RequestHandler handler = handlerFactory.getHandler(command, service);
            String destination = handler.handleRequest(request, response);

            // If the response is already committed, for example for sendRedirect
            if (!response.isCommitted()) {
                handler.forwardRequest(destination, request, response);
            }
        } catch (NotAuthorizedException e) {
            response.sendRedirect(request.getContextPath() + "/Controller?command=Login");
        }
    }
}

