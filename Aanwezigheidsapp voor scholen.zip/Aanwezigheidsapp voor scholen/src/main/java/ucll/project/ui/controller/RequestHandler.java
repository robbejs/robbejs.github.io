package ucll.project.ui.controller;

import ucll.project.domain.service.DatabaseService;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public abstract class RequestHandler {
    private DatabaseService service;

    public RequestHandler(String command, DatabaseService service){
        setService(service);
    }

    private void setService(DatabaseService service){
        if (service == null)
            throw new ControllerException("Country service cannot be null.");

        this.service = service;
    }

    public DatabaseService getService(){ return service; }

    public abstract String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException;

    void forwardRequest(String destination, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher view = request.getRequestDispatcher(destination);
        view.forward(request, response);
    }


}
