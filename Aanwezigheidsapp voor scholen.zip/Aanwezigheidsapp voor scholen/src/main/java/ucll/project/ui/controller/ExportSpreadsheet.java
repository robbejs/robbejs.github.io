package ucll.project.ui.controller;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import ucll.project.domain.model.DomainException;
import ucll.project.domain.model.HourCount;
import ucll.project.domain.model.User;
import ucll.project.domain.service.DatabaseService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class ExportSpreadsheet extends RequestHandler {
    XSSFWorkbook workbook;
    XSSFSheet sheet;
    boolean multipleUsers;
    int i = 1;

    public ExportSpreadsheet(String command, DatabaseService service) {
        super(command, service);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (!request.getMethod().equalsIgnoreCase("GET")) return "errors/405.jsp";

        // Create sheet
        this.workbook = new XSSFWorkbook();
        this.sheet = workbook.createSheet("Presence per day");

        // If should execute for all students
        if (request.getParameter("all") != null && request.getParameter("all").equalsIgnoreCase("yes")) {
            this.multipleUsers = true;

            this.writeHeaderLine();

            // Loop users
            ResultSet result = getService().getLessonService().getLessonHourCountByIdPerDayForAllStudents();

            try {
                // For every item in the result set
                while (result.next()) {
                    User user = new User(
                        result.getString("user_id"), result.getString("first_name"), result.getString("last_name")
                    );
                    HourCount hour = new HourCount(
                        result.getString("date"), result.getDouble("present"), result.getDouble("online"), result.getDouble("total")
                    );

                    this.writeDataLine(hour, user);
                }
            } catch (SQLException e) {
                throw new DomainException(e);
            }

            this.setOutputStream(request, response, "all");
        } else {
            int id = Integer.parseInt(request.getParameter("id"));
            if (id <= 0) return "errors/404.jsp";

            User user = getService().getUserService().getUser(id);
            if (user == null) return "errors/404.jsp";

            writeHeaderLine();

            // Retrieve and write all hours
            List<HourCount> hours = getService().getLessonService().getLessonHourCountByIdPerDay(id);

            for (HourCount hour: hours)
                writeDataLine(hour, null);

            this.setOutputStream(request, response, user.getUserId().toLowerCase());
        }

        return "index.jsp";
    }

    private void writeHeaderLine() {
        Row headerRow = this.sheet.createRow(0);
        Cell headerCell;
        int rowCell = 0;

        if (this.multipleUsers) {
            headerCell = headerRow.createCell(rowCell++);
            headerCell.setCellValue("User ID");

            headerCell = headerRow.createCell(rowCell++);
            headerCell.setCellValue("First Name");

            headerCell = headerRow.createCell(rowCell++);
            headerCell.setCellValue("Last Name");
        }

        headerCell = headerRow.createCell(rowCell++);
        headerCell.setCellValue("Day");

        headerCell = headerRow.createCell(rowCell++);
        headerCell.setCellValue("Present");

        headerCell = headerRow.createCell(rowCell++);
        headerCell.setCellValue("Of which online");

        headerCell = headerRow.createCell(rowCell);
        headerCell.setCellValue("Total expected");
    }

    /**
     * Writes one specific line
     * @param hour
     * @param user
     */
    private void writeDataLine(HourCount hour, User user) {
        Row row = sheet.createRow(i++);
        int rowCell = 0;
        Cell cell;

        if (this.multipleUsers && user != null) {
            // Set present hours
            cell = row.createCell(rowCell++);
            cell.setCellValue(user.getUserId());

            // Set present hours
            cell = row.createCell(rowCell++);
            cell.setCellValue(user.getFirstName());

            // Set present hours
            cell = row.createCell(rowCell++);
            cell.setCellValue(user.getLastName());
        }

        // Set date
        cell = row.createCell(rowCell++);
        CellStyle cellStyle = workbook.createCellStyle();
        CreationHelper creationHelper = workbook.getCreationHelper();
        cellStyle.setDataFormat(creationHelper.createDataFormat().getFormat("dd-MM-yyyy"));
        cell.setCellStyle(cellStyle);
        cell.setCellValue(hour.getDate());

        // Set present hours
        cell = row.createCell(rowCell++);
        cell.setCellValue(hour.getPresent());

        // Set online hours
        cell = row.createCell(rowCell++);
        cell.setCellValue(hour.getOnline());

        // Set total hours
        cell = row.createCell(rowCell++);
        cell.setCellValue(hour.getTotal());
    }

    private void setOutputStream(HttpServletRequest request, HttpServletResponse response, String fileName) throws IOException {
        // Set content type
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

        // Forces download
        String headerKey = "Content-Disposition";
        String headerValue = String.format("attachment; filename=\"%s\"", "report-" + fileName + ".xls");
        response.setHeader(headerKey, headerValue);

        // Output stream
        OutputStream outputStream = response.getOutputStream();
        this.workbook.write(outputStream);
        outputStream.close();
    }
}
