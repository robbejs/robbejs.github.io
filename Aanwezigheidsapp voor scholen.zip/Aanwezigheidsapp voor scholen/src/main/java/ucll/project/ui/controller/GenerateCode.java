package ucll.project.ui.controller;

import ucll.project.domain.model.Code;
import ucll.project.domain.model.RoleEnum;
import ucll.project.domain.service.DatabaseService;
import ucll.project.util.Checker;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class GenerateCode extends RequestHandler {
    List<String> errors = new ArrayList<>();

    public GenerateCode(String command, DatabaseService service) {
        super(command, service);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (request.getMethod().equals("POST"))
            return handlePOST(request, response);

        return "errors/405.jsp";
    }

    public String handlePOST(HttpServletRequest request, HttpServletResponse response) throws IOException {
        RoleEnum[] roles = {RoleEnum.LECTOR};
        Checker.checkRole(request, roles);

        int courseId = Integer.parseInt(request.getParameter("id"));
        String timestampText = request.getParameter("timestamp");
        LocalDateTime timestamp = null;

        if (timestampText != null && !timestampText.trim().equals("")) {
            try {
                timestamp = LocalDateTime.parse(timestampText, DateTimeFormatter.ISO_DATE_TIME);
            } catch (DateTimeParseException e) {
                errors.add("Het opgegeven tijdstip is ongeldig");
            }
        } else {
            errors.add("Het opgegeven tijdstip is ongeldig");
        }

        if (!errors.isEmpty()) {
            return "index.jsp";
        }

        Code code = new Code(courseId, timestamp);
        getService().getCodeService().addCode(code);

        response.sendRedirect(request.getContextPath() + "/Controller?command=ShowCourses&id=" + courseId);

        return "index.jsp";
    }
}
