package ucll.project.ui.controller;

import ucll.project.domain.model.Course;
import ucll.project.domain.model.RoleEnum;
import ucll.project.domain.model.User;
import ucll.project.domain.service.DatabaseService;
import ucll.project.util.Checker;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

public class Courses extends RequestHandler {
    public Courses(String command, DatabaseService service) {
        super(command, service);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) {
        if (request.getMethod().equals("GET"))
            return handleGET(request, response);

        return "errors/405.jsp";
    }

    /**
     *
     * @param request
     * @param response
     * @return show jsp
     */
    public String handleGET(HttpServletRequest request, HttpServletResponse response) {
        RoleEnum[] roles = {RoleEnum.LECTOR, RoleEnum.TRAJECTORYCOACH};
        Checker.checkRole(request, roles);

        User user = Checker.getUserInSession(request);

        List<Course> courses = getService().getCourseService().getAllOfLecturer(user.getId());

        request.setAttribute("courses", courses);

        return "courses/index.jsp";
    }
}
