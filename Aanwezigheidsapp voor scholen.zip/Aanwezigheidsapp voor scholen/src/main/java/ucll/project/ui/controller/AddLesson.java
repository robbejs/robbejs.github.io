package ucll.project.ui.controller;

import ucll.project.domain.model.DomainException;
import ucll.project.domain.model.Lesson;
import ucll.project.domain.model.RoleEnum;
import ucll.project.domain.service.DatabaseService;
import ucll.project.util.Checker;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class AddLesson extends RequestHandler {

    public AddLesson(String command, DatabaseService service) {
        super(command, service);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        RoleEnum[] roles = {RoleEnum.LECTOR};
        Checker.checkRole(request, roles);

        List<String> errors = new ArrayList<>();

        Lesson lesson = new Lesson();
        setLessonDescription(lesson, request, errors);
        setLessonGroup(lesson, request, errors);
        setLessonTimestamp(lesson, request, errors);
        setLessonDuration(lesson, request, errors);
        setLessonIsOnline(lesson, request, errors);

        if (errors.size() == 0) {
            try {
                int courseId = Integer.parseInt(request.getParameter("courseId"));
                getService().addLesson(lesson, courseId);

                response.sendRedirect(request.getContextPath() + "/Controller?command=ShowLessonCourse&id=" + courseId);
                return "";
            } catch (Exception e) {
                errors.add(e.getMessage());
            }
        }

        request.setAttribute("errors", errors);
        return "Controller?command=AddLessonForm";
    }

    private void setLessonDescription(Lesson lesson, HttpServletRequest request, List<String> errors) {
        try {
            String lessonDescription = request.getParameter("lessonDescription").trim();
            lesson.setDescription(lessonDescription);
            request.setAttribute("lessonDescriptionPrevious", lessonDescription);
        } catch (Exception e) {
            errors.add("Naam van de les is niet gegeven");
        }
    }

    private void setLessonTimestamp(Lesson lesson, HttpServletRequest request, List<String> errors) {
        String lessonDateString = request.getParameter("lessonDate").trim();
        String lessonTimeString = request.getParameter("lessonStartTime").trim();
        LocalDate lessonDate = null;
        LocalTime lessonTime = null;

        try {
            lessonDate = LocalDate.parse(lessonDateString);
        } catch (DateTimeParseException e) {
            errors.add("Datum van de les is niet ingegeven");
        }

        try {
            lessonTime = LocalTime.parse(lessonTimeString);
            request.setAttribute("lessonStartTimePrevious", lessonTimeString);
        } catch (DateTimeParseException e) {
            errors.add("Begin tijdstip van de les is niet gegeven");
        }

        try {
            if (lessonDate != null && lessonTime != null && !lessonDate.isBefore(LocalDate.now())) {
                LocalDateTime dateTime = LocalDateTime.of(lessonDate, lessonTime);
                Timestamp timestamp = Timestamp.valueOf(dateTime);
                lesson.setTimestamp(timestamp);
                request.setAttribute("lessonDatePrevious", lessonDateString);
            } else {
                errors.add("Datum van de les mag niet voor vandaag zijn");
            }
        } catch (DomainException e) {
            errors.add(e.getMessage());
        }
    }

    private void setLessonIsOnline(Lesson lesson, HttpServletRequest request, List<String> errors) {
        try {
            boolean lessonIsOnline = true;
            if (request.getParameter("checkboxLesson") == null) lessonIsOnline = false;
            lesson.setOnline(lessonIsOnline);
            request.setAttribute("checkboxLessonPrevious", lessonIsOnline);
        } catch (Exception e) {
            errors.add("Checkbox voor de les is niet gegeven");
        }
    }

    private void setLessonGroup(Lesson lesson, HttpServletRequest request, List<String> errors) {
        try {
            String lessonGroup = request.getParameter("lessonGroup").trim();
            lesson.setGroup(lessonGroup);
            request.setAttribute("lessonGroupPrevious", lessonGroup);
        } catch (Exception e) {
            errors.add("Reeks voor de les is niet gegeven");
        }
    }

    private void setLessonDuration(Lesson lesson, HttpServletRequest request, List<String> errors) {
        try {
            String lessonEndTimeString = request.getParameter("lessonEndTime").trim();
            LocalTime lessonEndTime = LocalTime.parse(lessonEndTimeString);
            Duration duration = Duration.between(lesson.getTimestamp().toLocalDateTime().toLocalTime(), lessonEndTime);
            lesson.setDuration(duration.toMinutes());
            request.setAttribute("lessonEndTimePrevious", lessonEndTimeString);
        } catch (Exception e) {
            errors.add("Eind tijdstip van de les is niet gegeven");
        }
    }
}
