package ucll.project.ui.controller;

import ucll.project.domain.service.DatabaseService;
import ucll.project.util.Checker;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class Index extends RequestHandler {
    public Index(String command, DatabaseService service) {
        super(command, service);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (request.getSession().getAttribute("user") == null)
            response.sendRedirect(request.getContextPath() + "/Controller?command=Login");

        return "index.jsp";
    }
}
