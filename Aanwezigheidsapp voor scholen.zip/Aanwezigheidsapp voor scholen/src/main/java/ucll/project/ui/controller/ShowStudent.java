package ucll.project.ui.controller;

import ucll.project.domain.model.HourCount;
import ucll.project.domain.model.User;
import ucll.project.domain.model.RoleEnum;
import ucll.project.domain.service.DatabaseService;
import ucll.project.util.Checker;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.List;

public class ShowStudent extends RequestHandler {

    public ShowStudent(String command, DatabaseService service) {
        super(command, service);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (!request.getMethod().equalsIgnoreCase("GET")) return "errors/405.jsp";

        RoleEnum[] roles = {RoleEnum.LECTOR, RoleEnum.STUDENTADMINISTRATION, RoleEnum.TRAJECTORYCOACH};
        Checker.checkRole(request, roles);

        int id = Integer.parseInt(request.getParameter("id"));
        if (id <= 0) return "errors/404.jsp";

        User user = getService().getUserService().getUser(id);
        if (user == null) return "errors/404.jsp";

        List<HourCount> hours = getService().getLessonService().getLessonHourCountByIdPerDay(id);

        this.setTotalHours(request, hours);
        request.setAttribute("shownuser", user);
        request.setAttribute("hours", hours);

        return "overview/showStudent.jsp";
    }

    private void setTotalHours(HttpServletRequest request, List<HourCount> hours) {
        DecimalFormat format = new DecimalFormat("###.#");
        double totalPresent = 0, total = 0, totalOnline = 0;

        for (HourCount hour: hours) {
            total += hour.getTotal();
            totalOnline += hour.getOnline();
            totalPresent += hour.getPresent();
        }

        request.setAttribute("total", format.format(total));
        request.setAttribute("totalOnline", format.format(totalOnline));
        request.setAttribute("totalPresent", format.format(totalPresent));
    }
}
