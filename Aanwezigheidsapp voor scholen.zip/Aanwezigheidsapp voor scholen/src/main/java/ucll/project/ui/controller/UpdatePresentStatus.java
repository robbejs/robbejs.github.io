package ucll.project.ui.controller;

import ucll.project.domain.model.Code;
import ucll.project.domain.model.Lesson;
import ucll.project.domain.model.RoleEnum;
import ucll.project.domain.model.User;
import ucll.project.domain.service.DatabaseService;
import ucll.project.util.Checker;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class UpdatePresentStatus extends RequestHandler {
    public UpdatePresentStatus(String command, DatabaseService service) {
        super(command, service);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // If should delete
        if (request.getMethod().equals("POST") && Boolean.parseBoolean(request.getParameter("delete")))
            return handleDELETE(request, response);

        if (request.getMethod().equals("POST"))
            return handlePOST(request, response);

        return "errors/405.jsp";
    }

    /**
     *
     * @param request
     * @param response
     * @return show jsp
     */
    public String handlePOST(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int lesson_id, user_id;

        RoleEnum[] roles = {RoleEnum.LECTOR};
        Checker.checkRole(request, roles);

        try {
            lesson_id = Integer.parseInt(request.getParameter("lesson_id"));
            user_id = Integer.parseInt(request.getParameter("user_id"));
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/Controller");
            return "";
        }

        Lesson lesson = getService().getLessonService().getById(lesson_id);
        User user = getService().getUserService().getUser(user_id);
        if (lesson == null || user == null) return "errors/404.jsp";

        getService().getLessonService().markUserAsPresent(user.getId(), lesson.getId());

        response.sendRedirect(request.getContextPath() + "/Controller?command=ShowCourses&id=" + lesson.getId());
        return "";
    }

    /**
     *
     * @param request
     * @param response
     * @return show jsp
     */
    public String handleDELETE(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int lesson_id, user_id;

        RoleEnum[] roles = {RoleEnum.LECTOR};
        Checker.checkRole(request, roles);

        try {
            lesson_id = Integer.parseInt(request.getParameter("lesson_id"));
            user_id = Integer.parseInt(request.getParameter("user_id"));
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/Controller");
            return "";
        }

        Lesson lesson = getService().getLessonService().getById(lesson_id);
        User user = getService().getUserService().getUser(user_id);
        if (lesson == null || user == null) return "errors/404.jsp";

        getService().getLessonService().deleteUserPresent(user.getId(), lesson.getId());

        response.sendRedirect(request.getContextPath() + "/Controller?command=ShowCourses&id=" + lesson.getId());
        return "";
    }
}
