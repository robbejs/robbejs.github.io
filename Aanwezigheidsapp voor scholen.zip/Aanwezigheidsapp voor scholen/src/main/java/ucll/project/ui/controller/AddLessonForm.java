package ucll.project.ui.controller;

import ucll.project.domain.model.RoleEnum;
import ucll.project.domain.service.DatabaseService;
import ucll.project.util.Checker;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class AddLessonForm extends RequestHandler {

    public AddLessonForm(String command, DatabaseService service) {
        super(command, service);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        RoleEnum[] roles = {RoleEnum.LECTOR};
        Checker.checkRole(request, roles);

        String courseId = request.getParameter("courseId");

        if (courseId == null || courseId.trim().equals("")) {
            response.sendRedirect(request.getContextPath() + "/Controller?command=Courses");
            return "index.jsp";
        }

        request.setAttribute("courseId", courseId);

        return "lessons/addLessonForm.jsp";
    }
}
