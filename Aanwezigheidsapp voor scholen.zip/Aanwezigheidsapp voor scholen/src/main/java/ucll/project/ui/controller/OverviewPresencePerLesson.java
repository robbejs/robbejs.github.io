package ucll.project.ui.controller;

import ucll.project.domain.model.RoleEnum;
import ucll.project.domain.service.DatabaseService;
import ucll.project.util.Checker;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class OverviewPresencePerLesson extends RequestHandler {

    public OverviewPresencePerLesson(String command, DatabaseService service) {
        super(command, service);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        RoleEnum[] roles = {RoleEnum.STUDENT};
        Checker.checkRole(request, roles);

        request.setAttribute("map", getService().getLessonsAndPresenceById(Checker.getUserInSession(request).getId()));

        return "lessons/overviewPresencePerLesson.jsp";
    }
}
