package ucll.project.ui.controller;

import ucll.project.domain.model.*;
import ucll.project.domain.service.DatabaseService;
import ucll.project.util.Checker;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class ShowLessonCourse extends RequestHandler {
    public ShowLessonCourse(String command, DatabaseService service) {
        super(command, service);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (request.getMethod().equals("GET"))
            return handleGET(request, response);

        return "errors/405.jsp";
    }

    /**
     *
     * @param request
     * @param response
     * @return show jsp
     */
    public String handleGET(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int courseId = Integer.parseInt(request.getParameter("id"));
        RoleEnum[] roles = {RoleEnum.LECTOR};
        Checker.checkRole(request, roles);

        Course course = getService().getCourseService().getById(courseId);

        if (course == null) {
            response.sendRedirect(request.getContextPath() + "/Controller?command=Courses");
            return "";
        }

        List<Lesson> lessons = getService().getLessonService().getCourseLessons(courseId);

        request.setAttribute("course", course);
        request.setAttribute("lessons", lessons);

        return "courses/show.jsp";
    }
}
