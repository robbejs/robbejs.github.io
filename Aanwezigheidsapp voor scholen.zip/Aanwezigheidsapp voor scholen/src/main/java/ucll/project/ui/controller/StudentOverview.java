package ucll.project.ui.controller;

import ucll.project.domain.model.User;
import ucll.project.domain.model.RoleEnum;
import ucll.project.domain.service.DatabaseService;
import ucll.project.util.Checker;

import java.util.List;
import java.io.IOException;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;

public class StudentOverview extends RequestHandler {

    public StudentOverview(String command, DatabaseService service) {
        super(command, service);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (!request.getMethod().equalsIgnoreCase("GET")) return "errors/405.jsp";
        RoleEnum[] roles = {RoleEnum.STUDENTADMINISTRATION, RoleEnum.TRAJECTORYCOACH};
        Checker.checkRole(request, roles);

        List<User> users = getService().getUserService().getAllStudents();
        request.setAttribute("users", users);

        return "overview/students.jsp";
    }
}
