package ucll.project.domain.db;

import ucll.project.domain.model.Course;
import ucll.project.domain.model.DomainException;
import ucll.project.domain.model.RoleEnum;
import ucll.project.domain.model.User;
import ucll.project.util.Checker;
import ucll.project.util.DbConnectionService;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDBSQL implements UserDB {
    private final Connection connection;
    private final String schema;

    public UserDBSQL() {
        connection = DbConnectionService.getDbConnection();
        schema = DbConnectionService.getSearchPath();
    }

    public List<User> getAll() {
        String sql_query = String.format("SELECT * FROM %s.users", this.schema);
        return getUsers(sql_query);
    }

    public List<User> getAllStudents() {
        String sql_query = String.format("SELECT * FROM %s.users WHERE role = 'STUDENT' ORDER BY user_id", this.schema);
        return getUsers(sql_query);
    }

    private List<User> getUsers(String sql_query) {
        List<User> users = new ArrayList<>();

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql_query);
            ResultSet result = statementSql.executeQuery();

            while (result.next()) {
                users.add(makeUser(result));
            }
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }

        return users;
    }

    public User getUser(int id) {
        if (id <= 0) throw new DomainException("ID cannot be lower than 0.");

        String sql = String.format("SELECT * FROM %s.users WHERE id = ?", schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql);
            statementSql.setInt(1, id);
            ResultSet result = statementSql.executeQuery();

            if (result.next()) return makeUser(result);
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }

        return null;
    }

    @Override
    public User getUser(String userId) {
        if (Checker.isEmptyString(userId)) throw new DomainException("User id can't be null");

        String sql = String.format("SELECT * FROM %s.users WHERE LOWER(user_id) = ?", schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql);
            statementSql.setString(1, userId.toLowerCase());
            ResultSet result = statementSql.executeQuery();

            if (result.next()) return makeUser(result);
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }

        return null;
    }

    @Override
    public int getIdUser(String userId) {
        if (Checker.isEmptyString(userId)) throw new DomainException("User id can't be null");
        int id=0;
        String sql = String.format("SELECT * FROM %s.users WHERE user_id = ?", this.schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql);
            statementSql.setString(1, userId);
            ResultSet result = statementSql.executeQuery();
            if(result.next()) {
                id = result.getInt("id");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            throw new DbException(e.getMessage(), e);
        }
        return id;
    }

    public List<User> getUserPerLesson(int lessonId) {
        if (lessonId == 0) throw new DomainException("lesson id can't be null");
        List<User> users = new ArrayList<>();
        String sql = String.format(
                "SELECT u.id, u.user_id, u.first_name, u.last_name, u.coach_id, ul.confirmed\n" +
                "FROM %s.lessons AS l\n" +
                "INNER JOIN %s.courses_users AS cu ON l.course_id = cu.course_id AND l.group = cu.group\n" +
                "LEFT OUTER JOIN %s.users_lessons AS ul ON cu.user_id = ul.user_id AND ul.lesson_id = l.id\n" +
                "INNER JOIN %s.users AS u ON u.id =  cu.user_id\n" +
                "WHERE l.id = ?",
                this.schema, this.schema, this.schema, this.schema
        );

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql);
            statementSql.setInt(1, lessonId);
            ResultSet result = statementSql.executeQuery();

            while (result.next()){
                users.add(new User(
                    result.getInt("id"),
                    result.getString("user_id"),
                    result.getString("first_name"),
                    result.getString("last_name"),
                    result.getString("confirmed")
                ));
            }
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }

        return users;
    }

    private User makeUser(ResultSet result) throws SQLException {
        int id = result.getInt("id");

        String userId = result.getString("user_id");
        String firstName = result.getString("first_name");
        String lastName = result.getString("last_name");

        String password = result.getString("password");

        String roleString = result.getString("role");
        RoleEnum roleEnum = RoleEnum.valueOf(roleString);

        return new User(id, userId, firstName, lastName, password, roleEnum);
    }
}
