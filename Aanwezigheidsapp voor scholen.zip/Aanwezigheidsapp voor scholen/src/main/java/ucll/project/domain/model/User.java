package ucll.project.domain.model;

import de.mkammerer.argon2.Argon2;
import de.mkammerer.argon2.Argon2Factory;
import ucll.project.util.Checker;

public class User {
    int id;
    private String userId, firstName, lastName, password, wasPresent;
    private RoleEnum roleEnum;
    private static final Argon2 argon2 = Argon2Factory.create();

    public User(String userId, String firstName, String lastName) {
        setUserId(userId);
        setFirstName(firstName);
        setLastName(lastName);
    }

    public User(String userId, String firstName, String lastName, String passwordHashed, RoleEnum roleEnum) {
        this(userId, firstName, lastName);
        setPasswordHashed(passwordHashed);
        setRoleEnum(roleEnum);
    }

    public User(int id, String userId, String firstName, String lastName, String passwordHashed, RoleEnum roleEnum) {
        this(userId, firstName, lastName, passwordHashed, roleEnum);
        setId(id);
    }

    public User(int id, String userId, String firstName, String lastName, String wasPresent) {
        setId(id);
        setUserId(userId);
        setFirstName(firstName);
        setLastName(lastName);
        setWasPresent(wasPresent);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        if (id <= 0) throw new IllegalArgumentException("ID cannot be null");

        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        if (Checker.isEmptyString(userId)) throw new DomainException("No first name given");
        this.userId = userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        if (Checker.isEmptyString(firstName)) throw new DomainException("No first name given");
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        if (Checker.isEmptyString(lastName)) throw new DomainException("No last name given");
        this.lastName = lastName;
    }

    public String getName() { return firstName + " " + lastName; }

    public String getPassword() {
        return password;
    }

    public void setPasswordHashed(String hashedPassword) {
        this.password = hashedPassword;
    }

    public void setPasswordUnhashed(String password) {
        this.password = hashPassword(password);
    }

    /**
     * Returns the given password as an Argon2 hash
     *
     * @param password cleartext password
     * @return hashed password
     */
    public static String hashPassword(String password) {
        // Transform the password in to an array of chars
        char[] passwordChars = password.toCharArray();

        // Make a hash
        String hash = argon2.hash(10, 65536, 1, passwordChars);

        // Delete the array
        argon2.wipeArray(passwordChars);

        return hash;
    }

    /**
     * Verifies the given password with the password hash of the user
     *
     * @param givenPassword password to check against the hash
     * @return if password matches true
     */
    public boolean verifyPasswordWithHash(String givenPassword) {
        return argon2.verify(this.getPassword(), givenPassword.toCharArray());
    }

    public RoleEnum getRoleEnum() {
        return roleEnum;
    }

    public void setRoleEnum(RoleEnum roleEnum) {
        if (roleEnum == null) throw new DomainException("Role can't be null");
        this.roleEnum = roleEnum;
    }

    public void setWasPresent(String wasPresent) {
        this.wasPresent = wasPresent;
    }

    public String getWasPresent() {
        if (wasPresent == null) {
            return "NO";
        } else if (wasPresent.equalsIgnoreCase("t")) {
            return "YES";
        } else {
            return "NOT_CONFIRMED";
        }
    }
}
