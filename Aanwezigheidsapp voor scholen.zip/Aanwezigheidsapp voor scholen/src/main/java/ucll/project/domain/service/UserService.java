package ucll.project.domain.service;

import ucll.project.domain.db.DbException;
import ucll.project.domain.db.UserDBSQL;
import ucll.project.domain.model.User;
import ucll.project.util.Checker;

import java.util.List;

public class UserService {
    private final UserDBSQL userDBSQL = new UserDBSQL();

    public UserService() {}

    public List<User> getAll() {
        return userDBSQL.getAll();
    }

    public List<User> getAllStudents() {
        return userDBSQL.getAllStudents();
    }

    /**
     * Look up the user using the database ID
     * @param id database ID
     * @return user model if found, otherwise null
     */
    public User getUser(int id) { return userDBSQL.getUser(id); }

    /**
     * Look up the user using the school ID
     * @param userId school ID
     * @return user model if found, otherwise null
     */
    public User getUser(String userId) {
        if (Checker.isEmptyString(userId)) throw new DbException("Gegevens zijn incorrect");

        return userDBSQL.getUser(userId);
    }

    public int getIdUser(String userId){
        return userDBSQL.getIdUser(userId);
    }

    public List<User> getUserPerLesson(int lessonId) {
        return userDBSQL.getUserPerLesson(lessonId);
    }
}
