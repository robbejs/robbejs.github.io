package ucll.project.domain.service;

import ucll.project.domain.model.Lesson;
import ucll.project.domain.model.User;

import java.util.Map;

public class DatabaseService {
    private final UserService userService = new UserService();
    private final CourseService courseService = new CourseService();
    private final CodeService codeService = new CodeService();
    private final LessonService lessonService = new LessonService();

    public DatabaseService() {}

    // ToDo: remove
    public User getUser(String userId) {
        return userService.getUser(userId);
    }

    public LessonService getLessonService() {
        return lessonService;
    }

    public UserService getUserService() { return userService; }

    public Map<Lesson, Boolean> getLessonsAndPresenceById(int id) {
        return lessonService.getLessonsAndPresenceById(id);
    }

    public void addLesson(Lesson lesson, int courseId) {
        lessonService.addLesson(lesson, courseId);
    }
    
    public CourseService getCourseService() {
        return courseService;
    }

    public CodeService getCodeService() {
        return codeService;
    }
}
