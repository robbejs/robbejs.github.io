package ucll.project.domain.db;

import ucll.project.domain.model.Course;
import ucll.project.domain.model.DomainException;
import ucll.project.domain.model.RoleEnum;
import ucll.project.domain.model.User;
import ucll.project.util.DbConnectionService;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CourseDB {
    private Connection connection;
    private String schema;

    public CourseDB() {
        this.connection = DbConnectionService.getDbConnection();
        this.schema = DbConnectionService.getSearchPath();
    }

    /**
     *
     *
    public void add(TestResult model) {
        if (model == null) return;

        String sql_insert = String.format(
                "INSERT INTO %s.test_results (timestamp, user_id) VALUES (?, ?)",
                this.schema
        );

        try {
            PreparedStatement statement = connection.prepareStatement(sql_insert);
            statement.setTimestamp(1, model.getTimestampForSql());
            statement.setInt(2, model.getUserId());
            statement.execute();
        } catch (SQLException e) {
            throw new DbException(e);
        }
    }*/

    public List<Course> getAll() {
        String sql_query = String.format("SELECT * FROM %s.courses", this.schema);
        List<Course> courses = new ArrayList<>();

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql_query);
            ResultSet result = statementSql.executeQuery();

            while (result.next()) {
                courses.add(makeCourseFromResult(result));
            }
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }

        return courses;
    }

    public List<Course> getAllOfLecturer(int userId) {
        if (userId <= 0) throw new IllegalArgumentException("Course ID cannot be 0 or lower");
        String sql_query = String.format("SELECT * FROM %s.courses WHERE user_id = ?", this.schema);
        List<Course> courses = new ArrayList<>();

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql_query);
            statementSql.setInt(1, userId);
            ResultSet result = statementSql.executeQuery();

            while (result.next()) {
                courses.add(makeCourseFromResult(result));
            }
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }

        return courses;
    }

    public Course getById(int courseId) {
        if (courseId <= 0) throw new IllegalArgumentException("Course ID cannot be 0 or lower");
        String sql_query = String.format("SELECT * FROM %s.courses WHERE id = ? LIMIT 1", this.schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql_query);
            statementSql.setInt(1, courseId);
            ResultSet result = statementSql.executeQuery();

            if (result.next()) {
                return makeCourseFromResult(result);
            }
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }

        return null;
    }

    public Course getByCode(String code) {
        if (code == null || code.trim().equals("")) throw new DomainException("Course code cannot be empty.");

        String sql_query = String.format("SELECT * FROM %s.courses WHERE register_code = ? LIMIT 1", this.schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql_query);
            statementSql.setString(1, code);
            ResultSet result = statementSql.executeQuery();

            if (result.next()) {
                return makeCourseFromResult(result);
            }
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }

        return null;
    }

    public List<User> getAllUsersOfCourse(int courseId) {
        if (courseId <= 0) throw new IllegalArgumentException("Course ID cannot be 0 or lower");

        ArrayList<User> users = new ArrayList<>();
        String sql_query = String.format("SELECT u.* FROM %s.courses_users AS cu INNER JOIN %s.users AS u ON cu.user_id = u.id WHERE course_id = ?", this.schema, this.schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql_query);
            statementSql.setInt(1, courseId);
            ResultSet result = statementSql.executeQuery();

            while (result.next()) {
                users.add(
                    new User(result.getInt("id"), result.getString("user_id"), result.getString("first_name"), result.getString("last_name"), result.getString("password"), RoleEnum.valueOf(result.getString("role")))
                );
            }
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }

        return users;
    }

    /*
    public TestResult getFirstById(int contactId) {
        String sql_query = String.format("SELECT * FROM %s.test_results WHERE user_id = ? ORDER BY timestamp DESC LIMIT 1", this.schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql_query);
            statementSql.setInt(1, contactId);
            ResultSet result = statementSql.executeQuery();

            if (result.next()) {
                return makeTestResultFromEntry(result);
            }
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }

        return null;
    }*/

    public void addCoursesUsers(String userId, String courseId) {
        String sql = String.format("INSERT INTO %s.courses_users(course_id, user_id, confirmed) VALUES (?, ?, ?)", this.schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql);
            statementSql.setInt(1, Integer.parseInt(courseId));
            statementSql.setInt(2, Integer.parseInt(userId));
            statementSql.setBoolean(3, false);
            statementSql.execute();
        } catch (SQLException e) {
            throw new DbException(e);
        }
    }

    private Course makeCourseFromResult(ResultSet result) throws SQLException {
        return new Course(result.getInt("id"), result.getString("name"), result.getString("opo_code"), result.getString("register_code"));
    }
}