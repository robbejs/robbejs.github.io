package ucll.project.domain.model;

public class Course {
    int id;
    String name, opoCode, registerCode;

    public Course() {}

    public Course(int id, String name, String opoCode, String registerCode) {
        setId(id);
        setName(name);
        setOpoCode(opoCode);
        setRegisterCode(registerCode);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        if (id <= 0) throw new DomainException("Course ID must be higher than 0.");

        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.trim().equals("")) throw new DomainException("Name cannot be empty");

        this.name = name;
    }

    public String getOpoCode() {
        return opoCode;
    }

    public void setOpoCode(String opoCode) {
        if (opoCode == null || opoCode.trim().equals("")) throw new DomainException("OPO Code cannot be empty");

        this.opoCode = opoCode;
    }

    public String getRegisterCode() {
        return registerCode;
    }

    public void setRegisterCode(String registerCode) {
        this.registerCode = registerCode;
    }
}
