package ucll.project.domain.service;

import ucll.project.domain.model.User;
import ucll.project.domain.db.CourseDB;
import ucll.project.domain.model.Course;

import java.util.List;

public class CourseService {
    CourseDB courseDB = new CourseDB();

    public List<Course> getAll() {
        return courseDB.getAll();
    }

    public Course getById(int courseId) {
        return courseDB.getById(courseId);
    }

    public Course getByCode(String code) {
        return courseDB.getByCode(code);
    }

    public List<User> getAllUsersOfCourse(int id) {
        return courseDB.getAllUsersOfCourse(id);
    }

    public List<Course> getAllOfLecturer(int userId) {
        return courseDB.getAllOfLecturer(userId);
    }

    public void addCoursesUsers(String userId, String courseId) {
        courseDB.addCoursesUsers(userId, courseId);
    }
}
