package ucll.project.domain.db;

import ucll.project.domain.model.Code;
import ucll.project.domain.model.DomainException;
import ucll.project.util.DbConnectionService;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class CodeDB {
    private Connection connection;
    private String schema;

    public CodeDB() {
        this.connection = DbConnectionService.getDbConnection();
        this.schema = DbConnectionService.getSearchPath();
    }

    public boolean addCode(Code code)  {
        if (code == null) throw new DomainException("The code model cannot be empty.");
        String sql_query = String.format("INSERT INTO %s.codes (lesson_id, code, timestamp) VALUES (?, ?, ?)", this.schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql_query);
            statementSql.setInt(1, code.getCourseId());
            statementSql.setString(2, code.getCode());
            statementSql.setTimestamp(3, code.getTimestampForSQL());

            return statementSql.execute();
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }
    }

    public Code getByCode(String code) {
        if (code == null || code.trim().equals("")) throw new DomainException("The code cannot be empty.");

        String sql_query = String.format("SELECT * FROM %s.codes WHERE code = ? LIMIT 1", this.schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql_query);
            statementSql.setString(1, code);
            ResultSet result = statementSql.executeQuery();

            if (result.next()) {
                return makeCodeFromResult(result);
            }
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }

        return null;
    }

    public List<Code> getAllByCourseId(int courseId) {
        if (courseId <= 0) throw new DomainException("The course ID is invalid.");
        ArrayList<Code> codes = new ArrayList<>();

        String sql_query = String.format("SELECT * FROM %s.codes WHERE lesson_id = ? ORDER BY timestamp DESC", this.schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql_query);
            statementSql.setInt(1, courseId);
            ResultSet result = statementSql.executeQuery();

            while (result.next()) {
                codes.add(new Code(result.getInt("lesson_id"), result.getString("code"), result.getTimestamp("timestamp").toLocalDateTime()));
            }
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }

        return codes;
    }

    public List<Code> getAllCodesById(int lessonId) {
        if (lessonId <= 0) throw new DomainException("The course ID is invalid.");
        ArrayList<Code> codes = new ArrayList<>();

        String sql_query = String.format("select c.* FROM %s.lessons as l inner join %s.codes as c on c.lesson_id = l.id where c.lesson_id = ? ", this.schema, this.schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql_query);
            statementSql.setInt(1, lessonId);
            ResultSet result = statementSql.executeQuery();

            while (result.next()) {
                codes.add(new Code(result.getInt("lesson_id"), result.getString("code"), result.getTimestamp("timestamp").toLocalDateTime()));
            }
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }

        return codes;
    }

    public Code getByCodeByLesson(String code, int lesson_id) {
        String sql_query = String.format("SELECT * FROM %s.codes WHERE lesson_id = ? AND code = ? ", this.schema, this.schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql_query);
            statementSql.setInt(1, lesson_id);
            statementSql.setString(2, code);
            ResultSet result = statementSql.executeQuery();

            if (result.next())
                return new Code(result.getInt("lesson_id"), result.getString("code"), result.getTimestamp("timestamp").toLocalDateTime());
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }

        return null;
    }

    private Code makeCodeFromResult(ResultSet result) throws SQLException {
        LocalDateTime timestamp = result.getTimestamp("timestamp").toLocalDateTime();

        return new Code(result.getInt("lesson_id"), result.getString("code"), timestamp);
    }
}