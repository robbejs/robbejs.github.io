package ucll.project.domain.model;

import com.aventrix.jnanoid.jnanoid.NanoIdUtils;

import java.sql.Timestamp;
import java.time.LocalDateTime;

public class Code {
    String code;
    int courseId;
    LocalDateTime timestamp;

    private static final String alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

    public Code(int courseId, LocalDateTime timestamp) {
        this(courseId, generateNewCode(), timestamp);
    }

    public Code(int courseId, String code, LocalDateTime timestamp) {
        setCourseId(courseId);
        setCode(code);
        setTimestamp(timestamp);
    }

    public int getCourseId() {
        return courseId;
    }

    public String getCode() {
        return code;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public Timestamp getTimestampForSQL() {
        return Timestamp.valueOf(timestamp);
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public boolean hasExpired() {
        return LocalDateTime.now().isAfter(this.timestamp);
    }
  
    public static String generateNewCode() {
        return NanoIdUtils.randomNanoId(NanoIdUtils.DEFAULT_NUMBER_GENERATOR, alphabet.toCharArray(), 12);
    }
}
