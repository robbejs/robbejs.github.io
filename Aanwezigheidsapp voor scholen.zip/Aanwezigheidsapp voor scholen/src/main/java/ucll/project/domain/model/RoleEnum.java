package ucll.project.domain.model;

public enum RoleEnum {
    STUDENT,
    LECTOR,
    STUDENTADMINISTRATION,
    TRAJECTORYCOACH
}
