package ucll.project.domain.model;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class HourCount {
     DecimalFormat format = new DecimalFormat("###.#");
     LocalDate date;
     double present, online, total;

     public HourCount(String date, double present, double online, double total) {
         this.setDate(date);
         this.present = present;
         this.online = online;
         this.total = total;
     }

    public void setDate(String date) {
         try {
             this.date = LocalDate.parse(date, DateTimeFormatter.ISO_DATE);
         } catch (DateTimeParseException e) {
             throw new DomainException("The received date was invalid.");
         }
    }

    public LocalDate getDate() {
        return date;
    }

    public double getPresent() {
        return present;
    }

    public double getOnline() {
        return online;
    }

    public double getTotal() {
        return total;
    }

    public String getDateFormatted() {
         return date.format(DateTimeFormatter.ofPattern("dd MMM yy"));
    }

    public String getPresentFormatted() {
         return format.format(present);
    }

    public String getOnlineFormatted() {
        return format.format(online);
    }

    public String getTotalFormatted() {
        return format.format(total);
    }
}
