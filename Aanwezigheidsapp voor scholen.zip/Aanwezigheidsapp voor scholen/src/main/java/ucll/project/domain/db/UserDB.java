package ucll.project.domain.db;

import ucll.project.domain.model.User;

public interface UserDB {

    User getUser(String userId);

    int getIdUser(String userId);
}
