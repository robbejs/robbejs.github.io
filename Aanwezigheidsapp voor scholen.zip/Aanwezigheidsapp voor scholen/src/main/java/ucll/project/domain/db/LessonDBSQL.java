package ucll.project.domain.db;

import ucll.project.domain.model.DomainException;
import ucll.project.domain.model.HourCount;
import ucll.project.domain.model.Lesson;
import ucll.project.domain.model.RoleEnum;
import ucll.project.domain.model.User;
import ucll.project.util.DbConnectionService;

import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

public class LessonDBSQL {
    private final Connection connection;
    private final String schema;

    public LessonDBSQL() {
        connection = DbConnectionService.getDbConnection();
        schema = DbConnectionService.getSearchPath();
    }

    public Lesson getLesson(int id) {
        if (id <= 0) throw new DomainException("Id must be positive");

        String sql = String.format("SELECT * FROM %s.lessons WHERE id = ?", schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql);
            statementSql.setInt(1, id);
            ResultSet result = statementSql.executeQuery();

            if (result.next()) return makeLesson(result);
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }

        return null;
    }

    public void addLesson(Lesson lesson, int courseId) {
        System.out.println(lesson);
        System.out.println(courseId);
        if (courseId <= 0) throw new DomainException("Course id must be positive");

        String sql = String.format("INSERT INTO %s.lessons(description, \"timestamp\", is_online, \"group\", duration, course_id) VALUES (?, ?, ?, ?, ?, ?)", schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql);
            statementSql.setString(1, lesson.getDescription());
            statementSql.setTimestamp(2, lesson.getTimestamp());
            statementSql.setBoolean(3, lesson.isOnline());
            statementSql.setString(4, lesson.getGroup());
            statementSql.setDouble(5, lesson.getDuration());
            statementSql.setInt(6, courseId);
            System.out.println(statementSql);
            statementSql.execute();
        } catch (SQLException e) {
            throw new DbException(e);
        }
    }
  
    public List<HourCount> getLessonHourCountByIdPerDay(int user_id) {
        if (user_id <= 0) throw new DomainException("Id must be positive");

        ArrayList<HourCount> hours = new ArrayList<>();
        String sql = String.format(
                "SELECT to_char(l.timestamp, 'yyyy-MM-dd') AS date, SUM(\n" +
                "   CASE WHEN ul.user_id IS NULL OR l.is_online = 'no' THEN\n" +
                "       0\n" +
                "   ELSE\n" +
                "       l.duration\n" +
                "   END\n" +
                ") AS online, SUM(\n" +
                "    CASE WHEN ul.user_id IS NULL THEN\n" +
                "        0\n" +
                "    ELSE\n" +
                "        l.duration\n" +
                "    END\n" +
                ") AS present, SUM(l.duration) AS total\n" +
                "FROM %s.lessons AS l\n" +
                "INNER JOIN %s.courses_users AS uc ON uc.course_id = l.course_id AND uc.group = l.group\n" +
                "LEFT OUTER JOIN %s.users_lessons AS ul ON ul.lesson_id = l.id AND uc.user_id = ul.user_id\n" +
                "WHERE uc.user_id = ?\n" +
                "GROUP BY to_char(l.timestamp, 'yyyy-MM-dd')",
                this.schema, this.schema, this.schema
        );

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql);
            statementSql.setInt(1, user_id);
            ResultSet result = statementSql.executeQuery();

            while (result.next()) {
                hours.add(new HourCount(
                        result.getString("date"), result.getDouble("present"), result.getDouble("online"), result.getDouble("total")
                ));
            }
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }

        return hours;
    }

    public Map<Lesson, Boolean> getLessonsAndPresenceById(int id) {
        if (id <= 0) throw new DomainException("Id must be positive");
        Map<Lesson, Boolean> map = new HashMap<>();

        String sql = String.format("SELECT * FROM %s.users_lessons INNER JOIN %s.lessons ON lesson_id = id WHERE user_id = ? ORDER BY timestamp", schema, schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql);
            statementSql.setInt(1, id);
            ResultSet result = statementSql.executeQuery();

            while (result.next()) {
                map.put(makeLesson(result), result.getBoolean("confirmed"));
            }
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }

        return map;
    }

    public ResultSet getLessonHourCountByIdPerDayForAllStudents() {
        String sql = String.format(
                "SELECT u.user_id, u.first_name, u.last_name, to_char(l.timestamp, 'yyyy-MM-dd') AS date, SUM(\n" +
                        "   CASE WHEN ul.user_id IS NULL OR l.is_online = 'no' THEN\n" +
                        "       0\n" +
                        "   ELSE\n" +
                        "       l.duration\n" +
                        "   END\n" +
                        ") AS online, SUM(\n" +
                        "    CASE WHEN ul.user_id IS NULL THEN\n" +
                        "        0\n" +
                        "    ELSE\n" +
                        "        l.duration\n" +
                        "    END\n" +
                        ") AS present, SUM(l.duration) AS total\n" +
                        "FROM %s.lessons AS l\n" +
                        "INNER JOIN %s.courses_users AS uc ON uc.course_id = l.course_id AND uc.group = l.group\n" +
                        "INNER JOIN %s.users AS u ON uc.user_id = u.id\n" +
                        "LEFT OUTER JOIN %s.users_lessons AS ul ON ul.lesson_id = l.id AND uc.user_id = ul.user_id\n" +
                        "WHERE role = ?\n" +
                        "GROUP BY to_char(l.timestamp, 'yyyy-MM-dd'), u.id, u.first_name, u.last_name, u.user_id\n" +
                        "ORDER BY u.user_id, date",
                this.schema, this.schema, this.schema, this.schema
        );

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql);
            statementSql.setString(1, String.valueOf(RoleEnum.STUDENT));

            ResultSet result = statementSql.executeQuery();

            return result;
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }
    }

    private Lesson makeLesson(ResultSet result) throws SQLException {
        String description = result.getString("description");
        Timestamp timestamp = result.getTimestamp("timestamp");
        boolean is_online = result.getBoolean("is_online");
        String group = result.getString("group");
        double duration = result.getDouble("duration");
        int id = result.getInt("id");
        int course_id = result.getInt("course_id");

        return new Lesson(description, timestamp, is_online, group, duration, id, course_id);
    }

    public List<Lesson> getStudentLessons(int id) {
        ArrayList<Lesson> lessons = new ArrayList<>();
        if (id <= 0) throw new DomainException("Id must be positive");

        String sql_query = String.format("SELECT l.* FROM %s.courses_users as cu inner join %s.users as u on cu.user_id = u.id inner join %s.courses as c on cu.course_id = c.id inner join %s.lessons as l on l.course_id = c.id WHERE u.id = ? ORDER BY l.id ASC", this.schema, this.schema, this.schema, this.schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql_query);
            statementSql.setInt(1, id);
            ResultSet result = statementSql.executeQuery();

            while (result.next()) {
                lessons.add(
                        new Lesson(result.getString("description"), result.getTimestamp("timestamp"), result.getBoolean("is_online"), result.getString("group"), result.getDouble("duration"), result.getInt("id"), result.getInt("course_id"))
                );
            }
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }
        return lessons;
    }


    public List<Lesson> getCourseLessons(int id){
        ArrayList<Lesson> lessons = new ArrayList<>();
        if (id <= 0) throw new DomainException("Id must be positive");

        String sql_query = String.format("SELECT l.* FROM  %s.courses as c INNER JOIN  %s.lessons as l on l.course_id = c.id WHERE l.course_id = ?", this.schema, this.schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(sql_query);
            statementSql.setInt(1, id);
            ResultSet result = statementSql.executeQuery();

            while (result.next()) {
                lessons.add(
                        new Lesson(result.getString("description"), result.getTimestamp("timestamp"), result.getBoolean("is_online"), result.getString("group"), result.getDouble("duration"), result.getInt("id"), result.getInt("course_id"))
                );
            }
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }
        return lessons;
    }

    public void markUserAsPresent(int user_id, int lesson_id, boolean confirmed) {
        String lookup_query = String.format("SELECT * FROM %s.users_lessons WHERE user_id = ? AND lesson_id = ? LIMIT 1", this.schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(lookup_query);
            statementSql.setInt(1, user_id);
            statementSql.setInt(2, lesson_id);
            ResultSet result = statementSql.executeQuery();

            if (result.next()) {
                // If a result is found and confirmed is false we should not execute this
                // Otherwise a user can confirm itself
                if (!confirmed) return;

                String update_query = String.format("UPDATE %s.users_lessons SET confirmed = 'yes' WHERE user_id = ? AND lesson_id = ?", this.schema);

                statementSql = connection.prepareStatement(update_query);
                statementSql.setInt(1, user_id);
                statementSql.setInt(2, lesson_id);
                statementSql.execute();
            } else {
                String create_query = String.format("INSERT INTO %s.users_lessons (user_id, lesson_id, confirmed) VALUES (?, ?, ?)", this.schema);

                statementSql = connection.prepareStatement(create_query);
                statementSql.setInt(1, user_id);
                statementSql.setInt(2, lesson_id);
                statementSql.setBoolean(3, confirmed);
                statementSql.execute();
            }
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }
    }

    public void deleteUserPresent(int user_id, int lesson_id) {
        String lookup_query = String.format("DELETE FROM %s.users_lessons WHERE user_id = ? AND lesson_id = ?", this.schema);

        try {
            PreparedStatement statementSql = connection.prepareStatement(lookup_query);
            statementSql.setInt(1, user_id);
            statementSql.setInt(2, lesson_id);
            statementSql.execute();
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }
    }
}
