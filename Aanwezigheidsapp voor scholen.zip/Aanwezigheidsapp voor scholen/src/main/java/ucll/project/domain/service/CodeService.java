package ucll.project.domain.service;

import ucll.project.domain.db.CodeDB;
import ucll.project.domain.model.Code;
import ucll.project.domain.model.Course;
import ucll.project.domain.model.User;

import java.util.List;

public class CodeService {
    CodeDB codeDB = new CodeDB();

    public boolean addCode(Code code) { return codeDB.addCode(code); }

    public Code getByCode(String code) {
        return codeDB.getByCode(code);
    }

    public Code getByCodeByLesson(String code, int lesson_id) {
        return codeDB.getByCodeByLesson(code, lesson_id);
    }

    public List<Code> getAllByCourseId(int courseId) { return codeDB.getAllByCourseId(courseId); }

    public List<Code> getAllCodesById(int lessonId) {
        return codeDB.getAllCodesById(lessonId);
    }
}
