package ucll.project.domain.service;

import ucll.project.domain.db.LessonDBSQL;
import ucll.project.domain.model.HourCount;
import ucll.project.domain.model.Lesson;

import java.sql.Timestamp;
import java.util.List;
import java.sql.ResultSet;
import java.util.Map;

public class LessonService {
    final LessonDBSQL lessonDBSQL = new LessonDBSQL();

    public LessonService() {
    }

    public Lesson getById(int id) {
        return lessonDBSQL.getLesson(id);
    }

    public List<Lesson> getStudentLessons(int id){
        return lessonDBSQL.getStudentLessons(id);
    }

    public List<Lesson> getCourseLessons(int id) {
        return lessonDBSQL.getCourseLessons(id);
    }

    public void addLesson(Lesson lesson, int courseId) {
        lessonDBSQL.addLesson(lesson, courseId);
    }

    public List<HourCount> getLessonHourCountByIdPerDay(int user_id) {
        return lessonDBSQL.getLessonHourCountByIdPerDay(user_id);
    }

    public ResultSet getLessonHourCountByIdPerDayForAllStudents() {
        return lessonDBSQL.getLessonHourCountByIdPerDayForAllStudents();
    }

    /**
     * Mark the user as confirmed
     * @param user_id
     * @param lesson_id
     */
    public void markUserAsPresent(int user_id, int lesson_id) {
        lessonDBSQL.markUserAsPresent(user_id, lesson_id, true);
    }

    /**
     * Method for the user that registers itself
     * @param user_id
     * @param lesson_id
     */
    public void registerUser(int user_id, int lesson_id) {
        lessonDBSQL.markUserAsPresent(user_id, lesson_id, false);
    }

    public void deleteUserPresent(int user_id, int lesson_id) {
        lessonDBSQL.deleteUserPresent(user_id, lesson_id);
    }

    public Map<Lesson, Boolean> getLessonsAndPresenceById(int id) {
        return lessonDBSQL.getLessonsAndPresenceById(id);
    }
}
