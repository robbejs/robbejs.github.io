package ucll.project.domain.model;

import ucll.project.util.Checker;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class Lesson {
    int id, course_id;
    String description, group;
    Timestamp timestamp;
    boolean isOnline;
    double duration;

    public Lesson(String description, Timestamp timestamp, boolean isOnline, String group, double duration, int id, int course_id) {
        setDescription(description);
        setTimestamp(timestamp);
        setOnline(isOnline);
        setGroup(group);
        setDuration(duration);
        setId(id);
        setCourse_id(course_id);
    }

    public Lesson() {}

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        if (Checker.isEmptyString(description)) throw new DomainException("Description can't be null");
        this.description = description;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public LocalDate getDate() { return timestamp.toLocalDateTime().toLocalDate(); }

    public void setTimestamp(Timestamp timestamp) {
        if (timestamp == null) throw new DomainException("Timestamp lesson can't be null");
        this.timestamp = timestamp;
    }

    public boolean isOnline() {
        return isOnline;
    }

    public void setOnline(boolean online) {
        isOnline = online;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        if (Checker.isEmptyString(group)) throw new DomainException("Group can't be null");
        this.group = group;
    }

    public double getDuration() {
        return duration;
    }

    public void setDuration(double duration) {
        if (duration <= 0) throw new DomainException("Duration must be positive");
        this.duration = duration;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        if (id <= 0) throw new DomainException("Id must be positive");
        this.id = id;
    }

    public int getCourse_id() {
        return course_id;
    }

    public void setCourse_id(int course_id) {
        if (course_id <= 0) throw new DomainException("Course id must be positive");
        this.course_id = course_id;
    }

    public String getLessonTime(Timestamp timestamp, double duration) {
        long HOUR = 3600*1000;
        Date date = new Date(timestamp.getTime());
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        DateFormat dateFormat1 = new SimpleDateFormat("HH:mm");

        Date newDate = new Date((long) (date.getTime() + (duration) * HOUR));

        return dateFormat.format(date) + " " + (dateFormat1.format(date)) + "-" + dateFormat1.format(newDate);
    }
}
