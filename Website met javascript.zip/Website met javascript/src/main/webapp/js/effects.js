

$(function() {
    $(document).ready(function () {
        $('div.hidden').fadeIn(1000).removeClass('hidden');
    });
});